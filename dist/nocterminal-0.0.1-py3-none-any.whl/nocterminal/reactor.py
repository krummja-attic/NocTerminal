from __future__ import annotations


class Reactor:

    def __init__(self, core):
        self.core = core

    def update(self):
        pass
