from __future__ import annotations


class Commander:

    def __init__(self, core) -> None:
        self.core = core
